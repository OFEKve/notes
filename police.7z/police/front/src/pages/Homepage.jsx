import React, { useState } from "react"

const Homepage = () => {
  const [ads, setAds] = useState([])
  const [newAd, setNewAd] = useState({
    title: "",
    description: "",
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setNewAd((prevAd) => ({
      ...prevAd,
      [name]: value,
    }))
  }

  const handleAddAd = async (e) => {
    e.preventDefault()

    try {
      const res = await fetch("http://localhost:3000/ads", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newAd),
      })

      if (!res.ok) {
        throw new Error("Failed to add ad")
      }

      const data = await res.json()
      console.log("Ad added successfully:", data)

      setAds((prevAds) => [
        ...prevAds,
        {
          id: data._id,
          title: data.title,
          description: data.description,
        },
      ])

      setNewAd({
        title: "",
        description: "",
      })
    } catch (err) {
      console.error("Error adding ad:", err)
      alert("Failed to add ad.")
    }
  }

  const handleDeleteAd = async (adId) => {
    try {
      const res = await fetch(`http://localhost:3000/ads/${adId}`, {
        method: "DELETE",
      })

      if (!res.ok) {
        throw new Error("Failed to delete ad")
      }

      setAds((prevAds) => prevAds.filter((ad) => ad.id !== adId))
    } catch (err) {
      console.error("Error deleting ad:", err)
      alert("Failed to delete ad.")
    }
  }

  return (
    <div>
      <h1>Welcome to the Homepage</h1>
      <h2>Your Ads:</h2>

      <ul>
        {ads.map((ad) => (
          <li key={ad.id}>
            <h3>{ad.title}</h3>
            <p>{ad.description}</p>
            <button onClick={() => handleDeleteAd(ad.id)}>Delete</button>
          </li>
        ))}
      </ul>

      <hr />

      <h2>Add a New Ad:</h2>
      <form onSubmit={handleAddAd}>
        <div>
          <label htmlFor="title">Title:</label>
          <br />
          <input
            type="text"
            id="title"
            name="title"
            value={newAd.title}
            onChange={handleInputChange}
            placeholder="Enter ad title"
          />
        </div>
        <div>
          <label htmlFor="description">Description:</label>
          <br />
          <textarea
            id="description"
            name="description"
            value={newAd.description}
            onChange={handleInputChange}
            placeholder="Enter ad description"
          />
        </div>
        <button type="submit">Add Ad</button>
      </form>
    </div>
  )
}

export default Homepage
