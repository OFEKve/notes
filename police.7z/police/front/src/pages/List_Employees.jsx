import React from "react"
import TableRow from "../components/TableRow"

export const List_Employees = () => {
  return (
    <>
      <TableRow />
    </>
  )
}
