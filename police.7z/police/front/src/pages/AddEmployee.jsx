import React, { useState } from "react"

const AddEmployee = (props) => {
  const [employeeData, setEmployeeData] = useState({
    Name: "",
    password: "",
    LastName: "",
    City: "",
    Email: "",
  })

  const handleChange = (e) => {
    setEmployeeData({
      ...employeeData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    try {
      console.log(employeeData)
      const res = await fetch("http://localhost:3000/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(employeeData),
      })

      if (!res.ok) {
        throw new Error(`Error adding employee: ${res.statusText}`)
      }

      const data = await res.json()
      console.log(data)

      setEmployeeData({
        Name: "",
        password: "",
        LastName: "",
        City: "",
        Email: "",
      })
    } catch (err) {
      console.error("Error submitting form:", err)
      alert("Error while submitting form.")
    }
  }

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <div>
          <header className="border-l text-center text-xl">
            Employee Details
          </header>
        </div>
        <label htmlFor="name">Name</label>
        <input
          type="text"
          name="Name"
          value={employeeData.Name}
          className="form-control form-control-lg"
          placeholder="Enter your name"
          onChange={handleChange}
        />
        <h1>Password</h1>
        <input
          name="password"
          value={employeeData.password}
          className="form-control form-control-lg"
          type="password"
          placeholder="Enter your password"
          onChange={handleChange}
        />
        <h1>Last Name</h1>
        <input
          name="LastName"
          value={employeeData.LastName}
          className="form-control form-control-lg"
          type="text"
          placeholder="Enter your last name"
          onChange={handleChange}
        />
        <h1>Email</h1>
        <input
          name="Email"
          value={employeeData.Email}
          className="form-control form-control-lg"
          type="email"
          placeholder="Enter your email"
          onChange={handleChange}
        />
        <h1>City</h1>
        <input
          name="City"
          value={employeeData.City}
          className="form-control form-control-lg"
          type="text"
          placeholder="Enter your city"
          onChange={handleChange}
        />

        <div className="text-center">
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  )
}

export default AddEmployee
