import React, { useState } from "react"
import { useNavigate } from "react-router-dom"

const Login = () => {
  const [employeeData, setEmployeeData] = useState({
    Name: "",
    password: "",
  })

  const navigate = useNavigate()

  const handleChange = (e) => {
    setEmployeeData({
      ...employeeData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    const registeredUser = {
      name: employeeData.Name,
      password: employeeData.password,
    }

    console.log("Checking credentials:", registeredUser)

    try {
      const res = await fetch("http://localhost:3000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(registeredUser),
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data.message || "Login failed")
      }

      if (data.success) {
        alert("Login successful!")
        navigate("/homepage")
      } else {
        alert("Invalid login credentials. Please try again.")
      }
    } catch (err) {
      console.error("Error during login:", err)
      alert("Failed to login. Please check your username and password.")
    }
  }

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <div>
          <header className="border-l text-center text-xl">
            Login Details
          </header>
        </div>
        <label htmlFor="name">Name</label>
        <br />
        <input
          type="text"
          name="Name"
          value={employeeData.Name}
          className="form-control form-control-lg"
          placeholder="Enter your name"
          onChange={handleChange}
        />
        <br />
        <h1>Password</h1>
        <input
          name="password"
          value={employeeData.password}
          className="form-control form-control-lg"
          type="password"
          placeholder="Enter your password"
          onChange={handleChange}
        />

        <div className="text-center">
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  )
}

export default Login
