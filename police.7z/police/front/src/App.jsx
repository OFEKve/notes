import React from "react"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import Login from "../src/pages/Login"
import Homepage from "../src/pages/Homepage"
import AddEmployee from "./pages/AddEmployee"

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/Register" element={<AddEmployee />} />

        <Route path="/login" element={<Login />} />
        <Route path="/homepage" element={<Homepage />} />
      </Routes>
    </Router>
  )
}

export default App
