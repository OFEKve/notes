import React from "react"
import AddEmployee from "../pages/AddEmployee"

const TableRow = () => {
  return (
    <table className="table-hover table-dark table">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">First name</th>
          <th scope="col">Last Name</th>
          <th scope="col"> Id</th>
          <th scope="col"> Phone</th>
          <th scope="col"> More info</th>
          <th scope="col">Edit</th>
          <th scope="col"> Delete</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">1</th>
          <td>name</td>
          <td>last</td>
          <td>id</td>
          <td>Phone</td>
          <td>
            {" "}
            <button type="button" className="btn btn-secondary btn-sm">
              More
            </button>
          </td>
          <td>
            {" "}
            <button type="button" className="btn btn-primary btn-sm">
              Edit
            </button>
          </td>
          <td>
            {" "}
            <button type="button" className="btn btn-danger btn-sm">
              Delete
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  )
}

export default TableRow
