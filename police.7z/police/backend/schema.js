import mongoose from "mongoose";

const registerSchema = new mongoose.Schema({
  Name: { type: String, required: true },
  password: { type: String, required: true },
  LastName: { type: String, required: true },
  City: { type: String, required: true },
  Email: { type: String, required: true },
});

export const Register = mongoose.model("Register", registerSchema);
