import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import { Ad } from "./schema_ads.js";
import { Register } from "./schema.js";

const app = express();
app.use(cors(origin));
app.use(express.json());

const uri =
  "mongodb+srv://user:Ofek1234!@cluster0.1o0xz.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
const clientOptions = {
  serverApi: { version: "1", strict: true, deprecationErrors: true },
};

async function connectToDB() {
  try {
    console.log("Connecting to MongoDB...");
    await mongoose.connect(uri, clientOptions);
    console.log("Connected to MongoDB!");
  } catch (err) {
    console.error("Error connecting to MongoDB:", err);
  }
}

connectToDB();

app.post("/ads", async (req, res) => {
  try {
    const newAd = new Ad(req.body);
    const savedAd = await newAd.save();
    res.status(201).json(savedAd);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
app.post("/login", async (req, res) => {
  const { name, password } = req.body;

  try {
    // חיפוש משתמש עם שם המשתמש
    const user = await Register.findOne({ Name: name });

    if (!user) {
      return res
        .status(401)
        .json({ success: false, message: "User not found" });
    }

    // אימות הסיסמה (ישירות בלי הצפנה)
    if (user.password !== password) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid password" });
    }

    // אם הסיסמה תואמת, החזר תשובה חיובית
    res.json({ success: true, message: "Login successful", user: user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

app.post("/", async (req, res) => {
  const { Name, password, LastName, City, Email } = req.body;

  if (!Name || !password || !LastName || !City || !Email) {
    return res.status(400).json({ error: "All fields are required" });
  }

  try {
    const newRegister = new Register({
      Name,
      password,
      LastName,
      City,
      Email,
    });

    const savedRegister = await newRegister.save();
    res.status(201).json(savedRegister);
  } catch (err) {
    console.error("Error during registration:", err);
    res.status(400).json({ error: err.message });
  }
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
