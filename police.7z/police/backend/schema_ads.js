import mongoose from "mongoose";

const adSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
});

export const Ad = mongoose.model("Ad", adSchema);
